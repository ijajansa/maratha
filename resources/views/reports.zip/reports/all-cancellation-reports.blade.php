@extends('layouts.app')
@section('content')
<!-- content @s -->
<div class="nk-content" style="margin-top: 50px;">
	<div class="container-fluid">
		<div class="nk-content-inner">
			<div class="nk-content-body">
				<div class="components-preview  mx-auto">                    
					<div class="nk-block nk-block-lg">
						@if(session('error'))
						<div class="alert alert-danger alert-icon"><em class="icon ni ni-cross-circle"></em> <strong>{{session('error')}}</strong></div>
						@endif
						@if(session('success'))
						<div class="alert alert-success alert-icon"><em class="icon ni ni-check-circle"></em> <strong>{{session('success')}}</strong></div>
						@endif
						<div class="nk-block-head" style="display: flex;">

							<div class="nk-block-head-content" style="width: 50%">
								<h4 class="nk-block-title">Cancellation Report</h4>
							</div>
							
						</div>
						<div class="card card-preview">
							<div class="card-inner">
								<div class="row">
									<div class="col-lg-3 col-sm-3">
										<label class="form-label">Booking From</label>
										<input type="date" class="form-control" id="from_date" onchange="applyFilter(this.value)">
									</div>
									<div class="col-lg-3 col-sm-3">
										<label class="form-label">Booking To</label>
										<input type="date" class="form-control" id="to_date" onchange="applyFilter(this.value)">
									</div>
									<div class="col-lg-3 col-sm-3">
										<label class="form-label">Select Address Type</label>
										<select class="form-control form-select" id="type" onchange="applyFilter(this.value)">
											<option value="null">Select Type</option>
											<option value="Self Pickup">Self Pickup</option>
											<option value="Delivery at Location">Delivery at Location</option>
										</select>
									</div>
									<div class="col-lg-3 col-sm-3">
										<label class="form-label">Select Category</label>
										<select class="form-control form-select" id="category_id" data-search-="on" onchange="applyFilter(this.value)">
											<option value="null">Select Category</option>
											@foreach($categories as $category)
											<option value="{{$category->id}}">{{$category->category_name}}</option>
											@endforeach
										</select>
									</div>
									<div class="col-lg-3 col-sm-3 mt-2">
										<label class="form-label">Select Brand</label>
										<select class="form-control form-select" id="brand_id"  data-search-="on" onchange="applyFilter(this.value)">
											<option value="null">Select Brand</option>
											@foreach($brands as $brand)
											<option value="{{$brand->id}}">{{$brand->brand_name}}</option>
											@endforeach
										</select>
									</div>
									<div class="col-lg-3 col-sm-3 mt-2">
										<label class="form-label">Select Store</label>
										<select class="form-control form-select" id="store_id"  data-search-="on" onchange="applyFilter(this.value)">
											<option value="null">Select Store</option>
											@foreach($stores as $store)
											<option value="{{$store->id}}">{{$store->store_name}}</option>
											@endforeach
										</select>
									</div>
									<!-- <div class="col-lg-3 col-sm-3 mt-2">
										<button class="btn btn-primary btn-md"><i class="ni ni-download" style="font-size: 18px;"></i>&nbsp;&nbsp;Export Excel</button>
									</div> -->
									<div class="col-lg-12 mt-2">
										<table class="nowrap table" id="myTable">
									<thead>
										<th>Id</th>
										<th>Booking Date</th>
										<th>Booking ID</th>
										<th>Advance Amount</th>
										<th>Customer Name</th>
										<th>Contact Number</th>
										<th>Category</th>
										<th>Bike</th>
										<th>Store</th>
										<th>Status</th>
									</thead>
									<tbody>

									</tbody>
								</table>
									</div>
								</div>
								
							</div>
						</div><!-- .card-preview -->
					</div> <!-- nk-block -->
				</div><!-- .components-preview -->
			</div>
		</div>
	</div>

</div>
<!-- content @e -->



<script type="text/javascript">

	function applyFilter()
	{
		$("#myTable").DataTable().clear().destroy();
		loadData();
	}

	$(document).ready(function(){
		loadData();
	});

	function loadData()
	{

		from_date = $("#from_date").val();
		to_date = $("#to_date").val();
		type = $("#type").val();
		category_id = $("#category_id").val();
		brand_id = $("#brand_id").val();
		store_id = $("#store_id").val();

		NioApp.DataTable('#myTable', {
			"processing": true,
			"serverSide": true,
			"searching":false,
			"bLengthChange":false,
			"responsive": true,
			ajax:"{{url('cancellation-reports/all')}}?from_date="+from_date+"&to_date="+to_date+"&type="+type+"&category_id="+category_id+"&brand_id="+brand_id+"&store_id="+store_id,
			"order":[
			[0,"asc"]
			],
			lengthMenu: [
			[10, 100, 500, -1],
			[10, 100, 500, "All"]
			],
			"columns":[
			{
                "mData":"id",
                render: function (data, type, row, meta) {
                    return meta.row + meta.settings._iDisplayStart + 1;
                }
            },
			{
				"mData":"booking_date"
			},
			{
				"mData":"booking_id"
			},
			{
				"mData":"advance_amount"
			},
			{
				"mData":"name"
			},
			{
				"mData":"contact_number"
			},
			{
				"mData":"category_name"
			},
			{
				"mData":"bike"
			},
			{
				"mData":"store_name"
			},
			
			{
				"targets":-1,
				"mData": "id",
				"bSortable": false,
				"ilter":false,
				"mRender": function(data, type, row){
					if(row.booking_status==8)
					{
						return '<span class="badge badge-sm badge-dot has-bg d-none d-sm-inline-flex" style="color:red">Cancelled</span>';
					}
				},

			},
			
			]          

		});
	}
</script>

@endsection